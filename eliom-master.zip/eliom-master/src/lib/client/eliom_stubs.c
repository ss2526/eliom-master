#include <stdlib.h>
#include <stdio.h>

void caml_unwrap_value_from_string () {
  fprintf(stderr, "Unimplemented Javascript primitive caml_unwrap_value_from_string!\n");
  exit(1);
}
