open Ppx_eliom_client [@@warning "-33"]

let () = Ppxlib.Driver.standalone ()
