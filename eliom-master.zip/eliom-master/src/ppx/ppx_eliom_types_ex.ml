open Ppx_eliom_type [@@warning "-33"]

let () = Ppxlib.Driver.standalone ()
