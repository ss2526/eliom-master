open Ppx_eliom_server [@@warning "-33"]

let () = Ppxlib.Driver.standalone ()
